
import FichendxDAO.Registro.Provincia;
import FichendxDAO.Registro.Sexo;
import FichendxDAO.Registro.Fecha;
import FichendxDAO.Registro.Empleado;
import FichendxDAO.Registro.Tipo;
import FichendxDAO.FichendxDAO;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Mejias Gonzalez Francisco\
 * @author Pablo
 * @author Andy Jan
 * @correcciones Álvaro añadido close(), refactorización de nombre de metodos
 */
public class Practica {

    public static Empleado pedirDatos() {
        BufferedReader teclado;
        String entrada, nombre, dni;
        boolean valido;
        float salario = 0;
        char sexo, tipoEmple;
        Fecha fecha;
        String[] campos;
        short anio;
        byte provincia = 0, mes, dia;
        Empleado emple = null;


        try {

            teclado = new BufferedReader(new InputStreamReader(System.in));
            do {
                System.out.print("Introduce un DNI valido: ");
                dni = teclado.readLine();
            } while (!Practica.esDNIValido(dni));
            do {
                System.out.print("Introduce un nombre y apellidos: ");
                entrada = teclado.readLine();
            } while (!entrada.matches(""));
            nombre = entrada;
            do {
                System.out.print("Sexo(M/H): ");
                entrada = teclado.readLine();
            } while (!entrada.matches("[MH]"));
            sexo = entrada.charAt(0);
            do {
                valido = true;
                System.out.print("Introduce un salario >0: ");
                entrada = teclado.readLine();
                try {
                    salario = Float.parseFloat(entrada);
                } catch (NumberFormatException nfe) {
                    System.out.println("Tiene que ser un numérico real");
                    valido = false;
                }
            } while (!valido || salario < 0);
            do {
                do {
                    System.out.print("Introduce una fecha de ingreso valida año/mes/dia(xxxx/xx/xx): ");
                    entrada = teclado.readLine();
                } while (!entrada.matches("\\d{4}\\/\\d{2}\\/\\d{2}"));
                campos = entrada.split("[/]");
                anio = Short.parseShort(campos[0]);
                mes = Byte.parseByte(campos[1]);
                dia = Byte.parseByte(campos[2]);
            } while (!Fecha.esValida(anio, mes, dia));



            do {
                System.out.print("Introduce una letra del tipo del empleado (D,C,F): ");
                entrada = teclado.readLine();
            } while (!entrada.matches("[CFD]"));
            tipoEmple = entrada.charAt(0);
            do {
                valido = true;
                System.out.print("Introduce el número de una provincia(1-8): ");
                try {
                    entrada = teclado.readLine();
                    provincia = Byte.parseByte(entrada);
                } catch (NumberFormatException nfe) {
                    System.out.println("Debe ser un número entre 1 y 8");
                    valido = false;
                }
            } while (!valido || !entrada.matches("[1-8]"));
            fecha = new Fecha(anio, mes, dia);
            emple = new Empleado(dni, nombre, Sexo.fromCodigo(sexo), salario,
                    fecha, Tipo.fromCodigo(tipoEmple), Provincia.fromCodigo(provincia));
        } catch (IOException ioe) {
            System.out.println("Error de E/S pidiendo datos");
        }

        return emple;
    }

    public static boolean esDNIValido(String dni) {
        return dni.matches("^([XYZ]\\d{7}|\\d{8})[A-Z]$");
    }

    public static void menu() {

        System.out.println("");
        System.out.println("1.Altas");
        System.out.println("2.Bajas");
        System.out.println("3.Modificar salario");
        System.out.println("4.Listado de empleados, ordenado por DNI");
        System.out.println("5.Listado de empleados, orden de almacenamiento");
        System.out.println("6.Salir");
        System.out.println("");
        System.out.println("Introduce una opcion: ");
    }

    public static void main(String[] args) {
        FichendxDAO fichendxDAO = null;
        try {
            boolean esValido;
            Empleado emple;
            RandomAccessFile raf;
            BufferedReader teclado;
            byte opcion = 0;
            String dni;
            float salario = 0;
            teclado = new BufferedReader(new InputStreamReader(System.in));
            raf = new RandomAccessFile("fichendx.dat", "rw");
            final byte TAMANIOREGISTRO = 91;
            fichendxDAO = new FichendxDAO(raf, TAMANIOREGISTRO);
            do {
                try {
                    do {
                        Practica.menu();
                        opcion = Byte.parseByte(teclado.readLine());
                    } while (opcion < 1 || opcion > 6);
                } catch (NumberFormatException nfe) {
                    System.out.println("Dato invalido, teclee otro.");
                } catch (IOException ex) {
                    System.out.println("Error de E/S con teclado");
                }
                switch (opcion) {
                    case 1://Alta de empleado
                        emple = Practica.pedirDatos();
                        try {
                            fichendxDAO.escribir(emple, emple.getDni());
                        } catch (IOException ex) {
                            System.err.println("Error al escribir el empleado");
                        }
                        break;
                    case 2://Baja de empleado
                        System.out.println("Introduce el DNI del empleado a borrar: ");
                        try {
                            do {
                                dni = teclado.readLine();
                            } while (!Practica.esDNIValido(dni));

                            System.out.println(fichendxDAO.
                                    borrar(dni)
                                    ? "Empleado borrado correctamente"
                                    : "Empleado no ha podido ser borrado");
                        } catch (IOException ex) {
                            System.out.println("Error de E/S pidiendo DNI");
                        }

                        break;
                    case 3://Modificar salario empleado
                        try {
                            System.out.println("Introduce el DNI del empleado a cambiar sueldo: ");
                            do {
                                dni = teclado.readLine();
                            } while (!Practica.esDNIValido(dni));
                            emple = (Empleado) fichendxDAO.leer(dni);
                            System.out.println(emple != null
                                    ? "Introduce nuevo salario"
                                    : "No existe el empleado");
                            if (emple != null) {
                                do {
                                    esValido = true;
                                    try {
                                        salario = Float.parseFloat(teclado.readLine());
                                    } catch (NumberFormatException nfe) {
                                        System.out.println("dato invalido, teclee otro");
                                        esValido = false;
                                    }
                                } while (!esValido);
                                emple.setSalario(salario);
                                System.out.println(fichendxDAO.modificar(emple,
                                        emple.getDni())
                                        ? "Empleado modificado correctamente"
                                        : "No se ha podido modificar empleado");
                            }

                        } catch (IOException ex) {
                            System.out.println("Error de E/S pidiendo salario");
                        }


                        break;






                    case 4://Listado por dni
                        System.out.println("Listando por DNI");
                        System.out.println("");
                        TreeMap<String, Long> mapa = new TreeMap(fichendxDAO.getIndices());
                        for (Map.Entry<String, Long> entrada : mapa.entrySet()) {
                            try {
                                emple = (Empleado) fichendxDAO.
                                        leer(entrada.getKey());
                                System.out.println(emple.toString());
                            } catch (IOException ex) {
                                System.out.println("Error de E/S leyendo");
                            }

                        }
                        break;
                    case 5:
                        try {
                            //Listado por orden de almacenamiento
                            raf.seek(0);
                            while (raf.getFilePointer() < raf.length()) {
                                emple = (Empleado) fichendxDAO.leer();
                                if (emple != null) {
                                    System.out.println(emple.toString());
                                }
                            }
                        } catch (IOException ex) {
                            System.out.println("Error de E/S listando por orden de almacenamiento");
                        }
                        break;
                }
            } while (opcion != 6);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Practica.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            fichendxDAO.close();
        }
        
    }
}
